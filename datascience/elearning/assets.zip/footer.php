    <html>
    <body>
    <!-- ///////////////// Start of Footer /////////////////////////// -->
    <h3 class="text-center center-block">Companies where our students are working</h3>
    <div class="row text-center center-block">

      <div class="col-lg-2 col-md-2 text-center center-block"></div>
      <div class="col-lg-8 col-md-8 text-center center-block">
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center>
                <img src="assets/imgm/icons/compns/jpm.png" style="width:auto; height:80px;" class="img-responsive">
              </center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center><img src="assets/imgm/icons/compns/acc.png" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center> <img src="assets/imgm/icons/compns/quant.png" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center><img src="assets/imgm/icons/compns/mstan.jpg" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center><img src="assets/imgm/icons/compns/tcs.png" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center><img src="assets/imgm/icons/compns/mphasis.jpg" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center><img src="assets/imgm/icons/compns/ey.png" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="panel panel-default text-center center-block">
            <div class="panel-body" style="margin:7px;">
              <center><img src="assets/imgm/icons/compns/here.png" style="width:auto; height:80px;" class="img-responsive"></center>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-md-2"></div>
    </div>

    <section id="bottom" class="navclass">
      <div class="container-fluid hidden-xs hidden-sm" id="footer">
        <br><br><br>
        <div class="row">
          <div class="col-lg-12 col-md-12 text-center center-block">

            <div class="col-lg-2 col-md-2 text-left"></div>

            <div class="col-lg-8 col-md-8 text-left">
              <div class="col-md-4 text-left">

                <p><a style="margin-left: 60%; font-size:13px;" href="https://datascience.suvenconsultants.com/elearning/aboutus.php" target="_blank">About Us</a></p>
                <p><a style="margin-left: 60%; font-size:13px;" class="" href="https://www.youtube.com/user/rockyjagtiani" target="_blank">YouTube</a></p>
                <p><a style="margin-left: 60%; font-size:13px;" class="" href="https://www.linkedin.com/in/rocky-jagtiani-3b390649/" target="_blank">LinkedIn</a></p>
                <br><br><br><br>
              </div>
              <div class="col-md-4 text-left">

                <p><a class="" style="margin-left: 10%;font-size:13px;" href="https://datascience.suvenconsultants.com" target="_blank">Classroom training at Mumbai</a></p>
                <p><a class="" style="margin-left: 10%;font-size:13px;" href="#onlinecourses">List of Online Courses</a></p>
                <br><br><br><br>
              </div>
              <div class="col-md-4 text-left">

                <p><a class="" style="font-size:13px;" href="https://docs.google.com/forms/u/1/d/e/1FAIpQLScPpX9SPBQkjj5xklDta_EOO0mADa-st3Zw8941ThkS5woKCQ/viewform" target="_blank"><b style="color:#fcba03;">Join our Wait List</b></a></p>
                <p><a class="" style="font-size:13px;" href="https://datascience.suvenconsultants.com/elearning/refundpolicy.php" target="_blank">Refund Policy</a></p>
                <p><a class="" style="font-size:13px;" href="https://mail.google.com/mail/?view=cm&fs=1&to=rocky@suvenconsultants.com" target="_blank">Help & Support</a></p>
                <br><br><br><br>

              </div>
              <center classs="text-center">
                <footer style="font-size:13px;">&copy; 2020 Suven Consultants & Technology Pvt Ltd</footer>
              </center>
              <br><br><br>

            </div>
            <div class="col-lg-2 col-md-2 text-left"></div>
          </div>

        </div>


        <!-- end of row -->
      </div><!-- end of container-->


      <div class="container-fluid hidden-lg hidden-md" id="footer">
        <div class="row">
          <div class="col-sm-12 col-xs-12 text-center center-block">
            <!--<div class="col-sm-2 col-xs-2 text-left"></div>-->
            <div class="col-sm-12 text-center">
              <br>
              <p><a style="font-size:13px;" href="https://datascience.suvenconsultants.com/elearning/aboutus.php" target="_blank">About Us</a></p>
              <p><a style="font-size:13px;" class="" href="https://www.youtube.com/user/rockyjagtiani" target="_blank">YouTube</a></p>
              <p><a style="font-size:13px;" class="" href="https://www.linkedin.com/in/rocky-jagtiani-3b390649/" target="_blank">LinkedIn</a></p>
              <br>
            </div>
            <div class="col-sm-12 text-center">

              <p><a class="" style="font-size:13px;" href="https://datascience.suvenconsultants.com" target="_blank">Classroom training at Mumbai</a></p>
              <p><a class="" style="font-size:13px;" href="#onlinecourses">List of Online Courses</a></p>
              <br>
            </div>
            <div class="col-sm-12 text-center">

              <p><a class="" style="font-size:13px;" href="https://docs.google.com/forms/u/1/d/e/1FAIpQLScPpX9SPBQkjj5xklDta_EOO0mADa-st3Zw8941ThkS5woKCQ/viewform" target="_blank"><b style="color:#fcba03;">Join our Wait List</b></a></p>
              <p><a class="" style="font-size:13px;" href="https://datascience.suvenconsultants.com/elearning/refundpolicy.php" target="_blank">Refund Policy</a></p>
              <p><a class="" style="font-size:13px;" href="https://mail.google.com/mail/?view=cm&fs=1&to=rocky@suvenconsultants.com" target="_blank">Help & Support</a></p>
              <br><br>

            </div>
            <center classs="text-center">
              <footer style="font-size:13px;">&copy; 2020 Suven Consultants & Technology Pvt Ltd</footer>
            </center>
            <br><br>
          </div>
        </div>
              </div>
    </section>


    <!-- Popup Modal For Addresses -->
    <div id="addressModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <div class="modal-content">
          <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4><strong>SCTPL Training Room Addresses</strong></h4>
            <h5 class="modal-title">Centralized Contact No.: <strong>+91 9870014450</strong></h5>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <address class="chembur_address">
                </address>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <address class="borivali_address">
                </address>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <address class="thanenew_address">
                </address>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <address class="dadarnew_address">
                </address>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- SCRIPTS  Start-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.0/jquery.cookie.min.js"></script>

    


    <script>
      /* Validation JS Function For Login */
      function validateLogin() {
        var email = document.forms["loginForm"]["email"].value;
        var password = document.forms["loginForm"]["password"].value;
        var passlen = password.length.value;


        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (email == "" || email == null) {
          alert("Please Enter Your Email ID");
          return false;
        } else if (reg.test(email) == false) {
          alert("Invalid Email Address");
          return false;
        } else if (password == "" || password == null) {
          alert("Please Enter Your Password");
          return false;
        } else if (password.length < 8) {
          alert("Password length must be grater than 8 characters.");
          return false;
        }

      }

      /* Validation JS Function For Registration */
      function validateRegister() {
        var name = document.forms["registerForm"]["name"].value;
        var email = document.forms["registerForm"]["emailid"].value;
        var password = document.forms["registerForm"]["password"].value;
        var confirmpassword = document.forms["registerForm"]["confirm_password"].value;
        var contact = document.forms["registerForm"]["contact"].value;

        var phoneno = /^[0-9]*$/;

        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (name == "" || name == null) {
          alert("Please Enter Your Name");
          return false;
        } else if (email == "" || email == null) {
          alert("Please Enter Your Email ID");
          return false;
        } else if (reg.test(email) == false) {
          alert("Invalid Email Address");
          return false;
        } else if (password == "" || password == null) {
          alert("Please Enter Your Password");
          return false;
        } else if (password.length < 8) {
          alert("Password length must be greater than 8 characters");
          return false;
        } else if (confirmpassword == "" || confirmpassword == null) {
          alert("Confirm Password should not be empty");
          return false;
        } else if (password !== confirmpassword) {
          alert("Your password and confirmation password do not match.");
          return false;
        } else if (contact == "" || contact == null) {
          alert("Please Enter Your Contact Number");
          return false;
        } else if (phoneno.test(contact) == false) {
          alert("Please Enter Valid Contact Number");
          return false;
        }
      }

      /* Validation JS Function For Expert Registration */
      function validateExpert() {
        var e_name = document.forms["expertForm"]["ie_name"].value;
        var e_skill = document.forms["expertForm"]["ie_skill"].value;
        var e_mobile = document.forms["expertForm"]["ie_mobile"].value;
        var e_email = document.forms["expertForm"]["ie_email"].value;

        var phoneno = /^[0-9]*$/;
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (e_name == "" || e_name == null) {
          alert("Please Enter Your Name");
          return false;
        } else if (e_skill == "" || e_skill == null) {
          alert("Please Enter Your Skills");
          return false;
        } else if (e_mobile == "" || e_mobile == null) {
          alert("Please Enter Your Mobile No.");
          return false;
        } else if (phoneno.test(e_mobile) == false) {
          alert("Please Enter Valid Mobile No.");
          return false;
        } else if (e_email == "" || e_email == null) {
          alert("Please Enter Your Email ID");
          return false;
        } else if (reg.test(e_email) == false) {
          alert("Invalid Email Address");
          return false;
        }

      }

      

      $(document).ready(function() {

        $(".toggle-password").click(function() {
          $(this).toggleClass("fa-eye fa-eye-slash");
          var x = document.getElementById("password");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        });

        
      });

    </script>
    <!-- SCRIPTS END -->

    
    <script>
      // $(window).on("load", function() {
      //   if ($.cookie('subscribe') == null) {
      //     setTimeout(function() {
      //       $('#subscribeModal').modal('show');
      //     }, 8000);
      //   }
      // });

      // console.log("hello world");

  


    // Ajax Call for Subscription
    // $(document).on('click', '#subscribeme', function(){
    //   var formdata = $("#subscribeForm").serialize();
    //   console.log(formdata)
    //   var subdata_e = document.getElementById("subscribe_email").value;
    //   var subdata_n = document.getElementById("subscribe_name").value;
    //   var subdata_c = document.getElementById("subscribe_contact").value;
    //   console.log(subdata_e);
    //   console.log(subdata_n);
    //   console.log(subdata_c);
    //   if(subdata_e == "" || subdata_e == null && subdata_n == "" || subdata_n == null && subdata_c == "" || subdata_c == null){
    //     alert("Please enter all details");
    //   }else{
    //     $(#subscribeModal).modal('hide');
    //     $.ajax({
    //       url:'subscribeus.php',
    //       method:'post',
    //       data: formdata,
    //       success:function(){
    //         $("#displayinModal").html(data);
    //         $('#actionsModal').modal('show');
    //       }
    //     });
    //   }
    // });
    </script>


    <!--End of Tawk.to Script-->

    <!--<div class="training hidden-xs hidden-sm">-->
    <!--  <p>Register for free : training - <a href="https://goo.gl/forms/D1MXNNbAnxdLers72" target="_blank"><b>here</b></a></p>-->
    <!--  <p><a href="https://drive.google.com/file/d/0B4rCFkKCsCeKc0pDZDdQY3dmVG8/view" target="_blank"><b>Download Information Brochure</b></a></p>-->
    <!--</div>-->
    <!--<div class="codeint hidden-xs hidden-sm" style="margin-left:-5px;margin-bottom:-27px;">-->
    <!--  <p>-->
    <!--    <p>-->
    <!--      <Strong>Coding<br><br>Internships</strong>-->
    <!--    </p>-->
    <!--    <p><a href="https://internship.suvenconsultants.com/" target="_blank"><b>Apply Here</b></a></p>-->


    <!--</div>-->
    <!--<div class="freshers hidden-sm hidden-xs" style="margin-left:-5px; line-height:10px;">-->
    <!--  <p><Strong>Freshers</strong></p>-->
    <!--  <p><a href="https://freshers.suvenconsultants.com/" target="_blank" style="font-size:11px;"><b>Apply Here</b></a></p>-->
    <!--</div>-->

  </body>
  <script>
    function python_rar() {
      var pwd = prompt("Please enter a Password", "");
      if (pwd == "rocky0809Py") {

        window.open("downloads/suvenPythonWorkspace.rar", "_blank");
      } else {
        alert("Password you enter was incorrect");
      }

    }

    function python_rar2() {
      var pwd = prompt("Please enter a Password", "");
      if (pwd == "rocky0809ML") {

        window.open("https://drive.google.com/open?id=13AOSD8amnk8iNwJmeP0pwIgKSBF12g70", "_blank");
      } else {
        alert("Password you enter was incorrect");
      }

    }


    function aml(link_number) {


      var pwd = prompt("Please enter a Password", "");

      if (pwd == "Lokesh2020AmL") {
        if (link_number == 2) {
          window.open("downloads/part 3_Exploring and Proccessing text data.rar", "_blank");
        } else if (link_number == 3) {
          window.open("downloads/part 4_Converting Text to Features.rar", "_blank");
        } else if (link_number == 4) {
          window.open("downloads/part 5_Advanced NLP.rar", "_blank");
        } else if (link_number == 5) {
          window.open("downloads/part 6_Four Real_World Case Studies n Solutions.rar", "_blank");
        } else if (link_number == 6) {
          window.open("downloads/part 7_Deep Learning in NLP.rar", "_blank");
        } else if (link_number == 7) {
          window.open("https://drive.google.com/open?id=0B0sr7hUZERtfbjRzU2NyVV90X0U", "_blank");
        } else if (link_number == 8) {
          window.open("https://drive.google.com/open?id=0B0sr7hUZERtfaGRsXzU5UThPc0U", "_blank");
        } else if (link_number == 9) {
          window.open("https://drive.google.com/open?id=1EdHBcWmpDyxvDm25jiXnTLAG_EiD8ps3", "_blank");
        } else if (link_number == 10) {
          window.open("https://drive.google.com/open?id=1B1BHQCs594ZPPZwlP3SNPboOU6F4OkTN", "_blank");
        } else if (link_number == 11) {
          window.open("https://db.suvenconsultants.com/machineLearningCompletePdf.pdf", "_blank");
        } else if (link_number == 12) {
          window.open("https://drive.google.com/open?id=1gi_95WvtTklyDHvLfy-fiWeicYIJXB2a", "_blank");
        }
      } else {
        alert("Password you enter was incorrect");
      }





    }



    function hadoop_pdf(link_number) {
      var pwd = prompt("Please enter a Password", "");

      if (pwd == "niraj0605Da") {
        if (link_number == 1) {
          window.open("https://drive.google.com/file/d/1N3JuJ-wCTu8qyrXiQbwg-em4CynFVP59/view", "_blank");
        } else if (link_number == 2) {
          window.open("https://drive.google.com/open?id=1r4Z0vu64BMBOqfjjYW_VSyUp7pREztIY", "_blank");
        } else if (link_number == 3) {
          window.open("https://drive.google.com/open?id=1pN_cypBV9qooB0dAgqyyi1wlQQjM6CuU", "_blank");
        } else if (link_number == 4) {
          window.open("downloads/HDFS_MapReduce Notes.rar", "_blank");
        } else if (link_number == 5) {
          window.open(" https://drive.google.com/open?id=0B4rCFkKCsCeKeEVhcjFrVnYybE0", "_blank");
        } else if (link_number == 6) {
          window.open("https://drive.google.com/open?id=0B4rCFkKCsCeKc01ENGNldm5heHM", "_blank");
        } else if (link_number == 7) {
          window.open("https://drive.google.com/open?id=0B0sr7hUZERtfbjRzU2NyVV90X0U", "_blank");
        } else if (link_number == 8) {
          window.open("https://drive.google.com/open?id=0B0sr7hUZERtfaGRsXzU5UThPc0U", "_blank");
        } else if (link_number == 9) {
          window.open("https://drive.google.com/open?id=1EdHBcWmpDyxvDm25jiXnTLAG_EiD8ps3", "_blank");
        } else if (link_number == 10) {
          window.open("https://drive.google.com/open?id=1B1BHQCs594ZPPZwlP3SNPboOU6F4OkTN", "_blank");
        } else if (link_number == 11) {
          window.open("https://db.suvenconsultants.com/machineLearningCompletePdf.pdf", "_blank");
        } else if (link_number == 12) {
          window.open("https://drive.google.com/open?id=1gi_95WvtTklyDHvLfy-fiWeicYIJXB2a", "_blank");
        }
      } else {
        alert("Password you enter was incorrect");
      }
    }

    $('.navbar-collapse a').click(function() {
      $(".navbar-collapse").collapse('hide');
    });

  </script>

  <script src="js/main1.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.0/jquery.cookie.min.js"></script>

</html>
